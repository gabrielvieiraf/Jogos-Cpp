#include <allegro5\allegro.h>
#include <allegro5\allegro_primitives.h>
#include <allegro5\allegro_font.h>
#include <allegro5\allegro_ttf.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#include "objects.h"

//GLOBALS==============================
const int WIDTH = 500;
const int HEIGHT = 700;
const int NUM_BULLETS = 9;
const int NUM_COMETS = 8;
const int NUM_STAR=100;
enum KEYS{UP, DOWN, LEFT, RIGHT, SPACE,P,W,S,A,D,ENTER};

bool keys[11] = {false, false, false, false, false, false, false, false, false,false,false};

ALLEGRO_SAMPLE *trilha=NULL;
ALLEGRO_SAMPLE *laser=NULL;
ALLEGRO_SAMPLE *explosao=NULL;
ALLEGRO_SAMPLE *aplausos=NULL;

ALLEGRO_SAMPLE_INSTANCE *inst_trilha=NULL;
ALLEGRO_SAMPLE_INSTANCE *inst_laser=NULL;
ALLEGRO_SAMPLE_INSTANCE *inst_explosao=NULL;
ALLEGRO_SAMPLE_INSTANCE *inst_aplausos=NULL;

//prototypes
void InitShip(SpaceShip &ship);
void DrawShip(SpaceShip &ship);
void MoveShipUp(SpaceShip &ship);
void MoveShipDown(SpaceShip &ship);
void MoveShipLeft(SpaceShip &ship);
void MoveShipRight(SpaceShip &ship);

void InitBullet(Bullet bullet[], int size);
void DrawBullet(Bullet bullet[], int size);
void FireBullet(Bullet bullet[], int size, SpaceShip &ship);
void UpdateBullet(Bullet bullet[], int size);
void CollideBullet(Bullet bullet[], int bSize, Comet comets[], int cSize, SpaceShip &ship);

void InitComet(Comet comets[], int size);
void DrawComet(Comet comets[], int size);
void StartComet(Comet comets[], int size);
void UpdateComet(Comet comets[], int size);
void CollideComet(Comet comets[], int cSize, SpaceShip &ship);

void InitPlano_1(Star star_p1[], int size);
void InitPlano_2(Star star_p2[], int size);
void InitPlano_3(Star star_p3[], int size);
void UpdatePlano_1(Star star_p1[], int size);
void UpdatePlano_2(Star star_p2[], int size);
void UpdatePlano_3(Star star_p3[], int size);
void DrawPlano_1(Star star_p1[], int size);
void DrawPlano_2(Star star_p2[], int size);
void DrawPlano_3(Star star_p3[], int size);


int main(void)
{
	//primitive variable
	int k;
	bool done = false;
	bool redraw = true;
	bool tocar_aplausos=false;
	const int FPS = 60;
	bool isGameOver = false;

	//object variables
	SpaceShip ship;
	Bullet bullets[NUM_BULLETS];
	Comet comets[NUM_COMETS];

	Star star_p1[NUM_STAR];
	Star star_p2[NUM_STAR];
	Star star_p3[NUM_STAR];



	//Allegro variables
	ALLEGRO_DISPLAY *display = NULL;
	ALLEGRO_EVENT_QUEUE *event_queue = NULL;
	ALLEGRO_TIMER *timer = NULL;
	ALLEGRO_FONT *font18 = NULL;
	ALLEGRO_FONT *font32 = NULL;
	ALLEGRO_AUDIO_STREAM *musica=NULL;

	//Initialization Functions
	if(!al_init())										//initialize Allegro
		return -1;

	display = al_create_display(WIDTH, HEIGHT);			//create our display object


if(!display)										//test display object
		return -1;

	al_init_primitives_addon();
	al_install_keyboard();
	al_init_font_addon();
	al_init_ttf_addon();

	al_install_audio();
    al_init_acodec_addon();

    al_reserve_samples(10);

	event_queue = al_create_event_queue();
	timer = al_create_timer(1.0 / FPS);

    font18 = al_load_font("Starjedi.ttf", 18, 0);
    font32 = al_load_font("arial.ttf", 32, 0);

    al_clear_to_color(al_map_rgb(0,0,0));
    al_draw_text(font18,al_map_rgb(250,0,0),WIDTH/2,HEIGHT/2,-1,"Carregando...");
    al_flip_display();

	trilha=al_load_sample("soundtrack.ogg");
	laser=al_load_sample("laser.wav");
	explosao=al_load_sample("explosao.wav");
	aplausos=al_load_sample("ovo.wav");

	inst_trilha=al_create_sample_instance(trilha);
    inst_laser=al_create_sample_instance(laser);
    inst_explosao=al_create_sample_instance(explosao);
    inst_aplausos=al_create_sample_instance(aplausos);

	al_attach_sample_instance_to_mixer(inst_trilha,al_get_default_mixer());
	al_attach_sample_instance_to_mixer(inst_laser,al_get_default_mixer());
	al_attach_sample_instance_to_mixer(inst_explosao,al_get_default_mixer());
	al_attach_sample_instance_to_mixer(inst_aplausos,al_get_default_mixer());


	al_set_sample_instance_playmode(inst_trilha,ALLEGRO_PLAYMODE_LOOP);
	al_set_sample_instance_gain(inst_trilha,0.8);

	srand(time(NULL));
	InitShip(ship);
	InitBullet(bullets, NUM_BULLETS);
	InitComet(comets, NUM_COMETS);

	InitPlano_1(star_p1,NUM_STAR);
    InitPlano_2(star_p2,NUM_STAR);
    InitPlano_3(star_p3,NUM_STAR);


	al_register_event_source(event_queue, al_get_keyboard_event_source());
	al_register_event_source(event_queue, al_get_timer_event_source(timer));
	al_register_event_source(event_queue, al_get_display_event_source(display));

	al_start_timer(timer);
	while(!done)
	{
		ALLEGRO_EVENT ev;
		al_wait_for_event(event_queue, &ev);

		if(ev.type == ALLEGRO_EVENT_TIMER)
		{
			redraw = true;
			if(keys[UP])
				MoveShipUp(ship);
			if(keys[DOWN])
				MoveShipDown(ship);
			if(keys[LEFT])
				MoveShipLeft(ship);
			if(keys[RIGHT])
				MoveShipRight(ship);
            if(keys[W])
				MoveShipUp(ship);
			if(keys[S])
				MoveShipDown(ship);
			if(keys[A])
				MoveShipLeft(ship);
			if(keys[D])
				MoveShipRight(ship);

                UpdatePlano_1(star_p1,NUM_STAR);
                UpdatePlano_2(star_p2,NUM_STAR);
                UpdatePlano_3(star_p3,NUM_STAR);


			if(!isGameOver)
			{
				al_play_sample_instance(inst_trilha);


				UpdateBullet(bullets, NUM_BULLETS);
				StartComet(comets, NUM_COMETS);
				UpdateComet(comets, NUM_COMETS);
				CollideBullet(bullets, NUM_BULLETS, comets, NUM_COMETS, ship);
				CollideComet(comets, NUM_COMETS, ship);


				if(ship.lives <= 0){
			      isGameOver = true;
				  tocar_aplausos=true;
					}
			}
			else{
                al_stop_sample_instance(inst_trilha);
                al_stop_sample_instance(inst_laser);
                al_stop_sample_instance(inst_explosao);


                if(tocar_aplausos)
                {
                       al_play_sample_instance(inst_aplausos);
                       tocar_aplausos=false;

                }

			}

		}
		else if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
		{
			done = true;
		}
		else if(ev.type == ALLEGRO_EVENT_KEY_DOWN)
		{
			switch(ev.keyboard.keycode)
			{
			case ALLEGRO_KEY_ESCAPE:
				done = true;
				break;
			case ALLEGRO_KEY_UP:
				keys[UP] = true;
				break;
			case ALLEGRO_KEY_DOWN:
				keys[DOWN] = true;
				break;
			case ALLEGRO_KEY_LEFT:
				keys[LEFT] = true;
				break;
			case ALLEGRO_KEY_RIGHT:
				keys[RIGHT] = true;
				break;
            case ALLEGRO_KEY_W:
				keys[W] = true;
				break;
			case ALLEGRO_KEY_S:
				keys[S] = true;
				break;
			case ALLEGRO_KEY_A:
				keys[A] = true;
				break;
			case ALLEGRO_KEY_D:
				keys[D] = true;
				break;
			case ALLEGRO_KEY_SPACE:
				keys[SPACE] = true;
				FireBullet(bullets, NUM_BULLETS, ship);
				break;
            case ALLEGRO_KEY_P:
				keys[P] = true;
				FireBullet(bullets, NUM_BULLETS, ship);
				break;
            case ALLEGRO_KEY_ENTER:
				keys[ENTER] = true;
				break;
			}
		}
		else if(ev.type == ALLEGRO_EVENT_KEY_UP)
		{
			switch(ev.keyboard.keycode)
			{
			case ALLEGRO_KEY_ESCAPE:
				done = true;
				break;
			case ALLEGRO_KEY_UP:
				keys[UP] = false;
				break;
			case ALLEGRO_KEY_DOWN:
				keys[DOWN] = false;
				break;
			case ALLEGRO_KEY_LEFT:
				keys[LEFT] = false;
				break;
			case ALLEGRO_KEY_RIGHT:
				keys[RIGHT] = false;
				break;
            case ALLEGRO_KEY_W:
				keys[W] = false;
				break;
			case ALLEGRO_KEY_S:
				keys[S] = false;
				break;
			case ALLEGRO_KEY_A:
				keys[A] = false;
				break;
			case ALLEGRO_KEY_D:
				keys[D] = false;
				break;
			case ALLEGRO_KEY_SPACE:
				keys[SPACE] = false;
				break;
            case ALLEGRO_KEY_P:
				keys[P] = false;
				FireBullet(bullets, NUM_BULLETS, ship);
				break;
            case ALLEGRO_KEY_ENTER:
				keys[ENTER] = false;
				break;
			}
		}

		if(redraw && al_is_event_queue_empty(event_queue))
		{
			redraw = false;

         DrawPlano_3(star_p3,NUM_STAR);
			DrawPlano_2(star_p2,NUM_STAR);
			DrawPlano_1(star_p1,NUM_STAR);


			if(!isGameOver)
			{


				DrawShip(ship);
				DrawBullet(bullets, NUM_BULLETS);
				DrawComet(comets, NUM_COMETS);




         if(ship.lives==1){
				al_draw_textf(font18, al_map_rgb(255, 0, 0), 5, 5, 0, "Cuidado!. Apenas uma vida");
				al_draw_textf(font18, al_map_rgb(255, 0, 0), 5,30, 0, "%i cometas destruidos", ship.score);

         }
         else{

              al_draw_textf(font18, al_map_rgb(255, 0, 0), 5, 5, 0, "Jogador com %i vidas faltando.", ship.lives);
				al_draw_textf(font18, al_map_rgb(255, 0, 0), 5,30, 0, "%i cometas destruidos", ship.score);
         }
			}
			else
			{
				al_draw_textf(font32, al_map_rgb(10, 189, 60 ), WIDTH / 2, HEIGHT / 2, ALLEGRO_ALIGN_CENTRE, "FIM DE JOGO" );
				al_draw_textf(font18, al_map_rgb(10, 189, 60), WIDTH / 2, (HEIGHT / 2)+30, ALLEGRO_ALIGN_CENTRE, " Cometas Destruidos: %i", ship.score);
                al_draw_textf(font18, al_map_rgb(241, 165, 9), WIDTH / 2, (HEIGHT / 2)+90, ALLEGRO_ALIGN_CENTRE, " Aperte ENTER para reiniciar");

			if(keys[ENTER])
            {
                 InitShip(ship);
               	 InitBullet(bullets, NUM_BULLETS);
                 InitComet(comets, NUM_COMETS);
	             InitPlano_1(star_p1,NUM_STAR);
                 InitPlano_2(star_p2,NUM_STAR);
                 InitPlano_3(star_p3,NUM_STAR);

                 al_stop_sample_instance(inst_aplausos);
                 al_play_sample_instance(inst_trilha);
                 isGameOver = false;

            }

			}


			al_flip_display();
			al_clear_to_color(al_map_rgb(0,0,0));
		}
	}

	al_destroy_event_queue(event_queue);
	al_destroy_timer(timer);
	al_destroy_font(font18);
	al_destroy_font(font32);
	al_destroy_display(display);						//destroy our display object

    al_destroy_sample(trilha);
    al_destroy_sample(laser);
    al_destroy_sample(explosao);
    al_destroy_sample(aplausos);

    al_destroy_sample_instance(inst_trilha);
    al_destroy_sample_instance(inst_laser);
    al_destroy_sample_instance(inst_explosao);
    al_destroy_sample_instance(inst_aplausos);

	return 0;
}

void InitShip(SpaceShip &ship)
{
	ship.x = WIDTH/2;
	ship.y = 646;
	ship.ID = PLAYER;
	ship.lives = 3;
	ship.speed = 7;
	ship.boundx = 6;
	ship.boundy = 7;
	ship.score = 0;
}
void DrawShip(SpaceShip &ship)
{

    al_draw_filled_rectangle(ship.x-11, ship.y-18 , ship.x-8, ship.y, al_map_rgb(250, 240, 240));
	al_draw_filled_rectangle(ship.x+11, ship.y-18 , ship.x +8, ship.y, al_map_rgb(250, 240, 240));
    al_draw_filled_rectangle(ship.x-11, ship.y-18 , ship.x-8, ship.y-13, al_map_rgb(250, 0, 0));
	al_draw_filled_rectangle(ship.x+11, ship.y-18 , ship.x +8, ship.y-13, al_map_rgb(250, 0, 0));
	al_draw_filled_rectangle(ship.x-5, ship.y-28 , ship.x + 5 , ship.y-16, al_map_rgb(250, 240, 240));
	al_draw_filled_rectangle(ship.x-2, ship.y-35 , ship.x + 2 , ship.y-28, al_map_rgb(250, 240, 240));
    al_draw_filled_rectangle(ship.x-17, ship.y-12 , ship.x-14, ship.y+4, al_map_rgb(250, 240, 240));
	al_draw_filled_rectangle(ship.x+17, ship.y-12 , ship.x +14, ship.y+4, al_map_rgb(250, 240, 240));
	al_draw_filled_rectangle(ship.x-17, ship.y-12 , ship.x-14, ship.y-8, al_map_rgb(250, 0, 0));
    al_draw_filled_rectangle(ship.x+17, ship.y-12 , ship.x+14, ship.y-8, al_map_rgb(250, 0, 0));
	al_draw_filled_triangle(ship.x - 20, ship.y+5 , ship.x +20, ship.y+5, ship.x , ship.y - 20, al_map_rgb(250, 240, 240));     al_draw_filled_rectangle(ship.x-3, ship.y+5 , ship.x+3, ship.y+3, al_map_rgb(250, 0, 0));
	al_draw_filled_rectangle(ship.x-11, ship.y+9 , ship.x-6, ship.y+3, al_map_rgb(250, 0, 0));
	al_draw_filled_rectangle(ship.x-15, ship.y+18 , ship.x-8, ship.y+9, al_map_rgb(250, 0, 0));
	al_draw_filled_rectangle(ship.x+11, ship.y+9 , ship.x+6, ship.y+3, al_map_rgb(250, 0, 0));
	al_draw_filled_rectangle(ship.x+15, ship.y+18 , ship.x+8, ship.y+9, al_map_rgb(250, 0, 0));
	al_draw_filled_rectangle(ship.x-8, ship.y+14 , ship.x+8, ship.y+3, al_map_rgb(250, 240, 240));
	al_draw_filled_rectangle(ship.x-1, ship.y+22 , ship.x+1, ship.y+14, al_map_rgb(250, 240, 240));
	al_draw_filled_rectangle(ship.x-2, ship.y-5 , ship.x+2, ship.y-10, al_map_rgb(250, 0, 0));
    al_draw_filled_rectangle(ship.x-6, ship.y-5 , ship.x-2, ship.y+3, al_map_rgb(250, 0, 0));
    al_draw_filled_rectangle(ship.x-2, ship.y-5 , ship.x+2, ship.y-1, al_map_rgb(250, 0, 0));
    al_draw_filled_rectangle(ship.x-2, ship.y-1 , ship.x+2, ship.y+3, al_map_rgb(250, 240, 240));
    al_draw_filled_rectangle(ship.x+2, ship.y-5 , ship.x+6, ship.y+3, al_map_rgb(250, 0, 0));

}
void MoveShipUp(SpaceShip &ship)
{
	ship.y -= ship.speed;
	if(ship.y < 0)
		ship.y = 0;
}
void MoveShipDown(SpaceShip &ship)
{
	ship.y += ship.speed;
	if(ship.y > HEIGHT)
		ship.y = HEIGHT;
}
void MoveShipLeft(SpaceShip &ship)
{
	ship.x -= ship.speed;
	if(ship.x < 0)
		ship.x = 0;
}
void MoveShipRight(SpaceShip &ship)
{
	ship.x += ship.speed;
	if(ship.x > WIDTH)
		ship.x = WIDTH;
}

void InitBullet(Bullet bullet[], int size)
{
	for(int i = 0; i < size; i++)
	{
		bullet[i].ID = BULLET;
		bullet[i].speed = 30;
		bullet[i].live = false;
	}
}
void DrawBullet(Bullet bullet[], int size)
{
	for( int i = 0; i < size; i++)
	{
		if(bullet[i].live)
			al_draw_filled_circle(bullet[i].x-18, bullet[i].y, 5, al_map_rgb(0, 255, 255));

	}
}
void FireBullet(Bullet bullet[], int size, SpaceShip &ship)
{
	for( int i = 0; i < size; i++)
	{
		if(!bullet[i].live)
		{
			bullet[i].x = ship.x + 17;
			bullet[i].y = ship.y;
			bullet[i].live = true;
			break;
		}
	}
}
void UpdateBullet(Bullet bullet[], int size)
{
	for(int i = 0; i < size; i++)
	{
		if(bullet[i].live)
		{  al_stop_sample_instance(inst_laser);
           al_play_sample_instance(inst_laser);

			bullet[i].y -= bullet[i].speed;
			if(bullet[i].y <=0)
				bullet[i].live = false;
		}
	}
}
void CollideBullet(Bullet bullet[], int bSize, Comet comets[], int cSize, SpaceShip &ship)
{
	for(int i = 0; i < bSize; i++)
	{
		if(bullet[i].live)
		{
			for(int j =0; j < cSize; j++)
			{
				if(comets[j].live)
				{
					if(bullet[i].x > (comets[j].x - comets[j].boundx) &&
						bullet[i].x < (comets[j].x + comets[j].boundx) &&
						bullet[i].y > (comets[j].y - comets[j].boundy) &&
						bullet[i].y < (comets[j].y + comets[j].boundy))
					{
					    al_stop_sample_instance(inst_explosao);
					    al_play_sample_instance(inst_explosao);

						bullet[i].live = false;
						comets[j].live = false;

						ship.score++;
					}
				}
			}
		}
	}
}

void InitComet(Comet comets[], int size)
{
	for(int i = 0; i < size; i++)
	{
		comets[i].ID = ENEMY;
		comets[i].live = false;
		comets[i].speed = 4;
		comets[i].boundx = 10;
		comets[i].boundy = 10;
		comets[i].raio=1;
		comets[i].r=0;
		comets[i].g=0;
		comets[i].b=0;
	}
}
void DrawComet(Comet comets[], int size)
{
	for(int i = 0; i < size; i++)
	{
		if(comets[i].live)
		{
			al_draw_filled_circle(comets[i].x, comets[i].y,comets[i].raio , al_map_rgb(comets[i].r, comets[i].g, comets[i].b));

		}
	}
}
void StartComet(Comet comets[], int size)
{
	for(int i = 0; i < size; i++)
	{
		if(!comets[i].live)
		{
			if(rand() % 500 == 0)
			{
				comets[i].live = true;
				comets[i].x = 50 + rand()%(WIDTH-60);
				comets[i].y = 0 ;

				break;
			}
		comets[i].boundx = 10;
		comets[i].boundy = 10;
		comets[i].raio=1;
		comets[i].r= 10+rand() % 240 + 1;
        comets[i].g= rand() % 240 + 1;
        comets[i].b= rand() % 240 + 1;
        comets[i].speed +=0.0008;


		}
	}
}
void UpdateComet(Comet comets[], int size)
{
	for(int i = 0; i < size; i++)
	{
		if(comets[i].live)
		{
			comets[i].y += comets[i].speed;
			comets[i].raio+=0.6;
			comets[i].boundx+=0.6;
			comets[i].boundy+=0.6;


		}
	}
}
void CollideComet(Comet comets[], int cSize, SpaceShip &ship)
{
	for(int i = 0; i < cSize; i++)
	{
		if(comets[i].live)
		{
			if(comets[i].x - comets[i].boundx < ship.x + ship.boundx &&
				comets[i].x + comets[i].boundx > ship.x - ship.boundx &&
				comets[i].y - comets[i].boundy < ship.y + ship.boundy &&
				comets[i].y + comets[i].boundy > ship.y - ship.boundy)
			{
			    al_stop_sample_instance(inst_explosao);
                al_play_sample_instance(inst_explosao);
				ship.lives--;
				comets[i].live = false;
			}
			else if(comets[i].y >=HEIGHT )
			{
				comets[i].live = false;
				ship.lives--;
			}
		}
	}
}

// PLANOS DE FUNDOS
void InitPlano_1(Star star_p1[], int size)
{
    for(int i=0; i<size; i++)
    {
        star_p1[i].ID = STAR;
        star_p1[i].x= 5 + rand() % (WIDTH-10);
        star_p1[i].y= 5 + rand() % (HEIGHT-10);
        star_p1[i].speed=6;

    }
}
void InitPlano_2(Star star_p2[], int size)
{
    for(int i=0; i<size;i++){
        star_p2[i].ID = STAR;
        star_p2[i].x= 5 + rand() % (WIDTH-10);
        star_p2[i].y= 5 + rand() % (HEIGHT-10);
        star_p2[i].speed=3;}
}
void InitPlano_3(Star star_p3[], int size)
{
       for(int i=0; i<size;i++){
        star_p3[i].ID = STAR;
        star_p3[i].x= 5 + rand() % (WIDTH-10);
        star_p3[i].y= 5 + rand() % (HEIGHT-10);
        star_p3[i].speed=1;}
}
void UpdatePlano_1(Star star_p1[], int size)
{
     for(int i=0;i<size;i++)
     {
         star_p1[i].y+=star_p1[i].speed;

         if(star_p1[i].y>HEIGHT)
         {
             star_p1[i].y= 0;
         }
     }
}
void UpdatePlano_2(Star star_p2[], int size)
{
    for(int i=0;i<size;i++)
     {
         star_p2[i].y+=star_p2[i].speed;

         if(star_p2[i].y>HEIGHT)
         {
             star_p2[i].y= 0;
         }
     }

}
void UpdatePlano_3(Star star_p3[], int size)
{
for(int i=0;i<size;i++)
     {
         star_p3[i].y+=star_p3[i].speed;

         if(star_p3[i].y>HEIGHT)
         {
             star_p3[i].y= 0;
         }
     }
}
void DrawPlano_1(Star star_p1[], int size)
{
     for(int i=0;i<size;i++)
     {
         al_draw_pixel(star_p1[i].x,star_p1[i].y,al_map_rgb(255,255,255));

     }
}
void DrawPlano_2(Star star_p2[], int size)
{
     for(int i=0;i<size;i++)
     {
         al_draw_pixel(star_p2[i].x,star_p2[i].y,al_map_rgb(255,255,255));

     }
}
void DrawPlano_3(Star star_p3[], int size)
{
     for(int i=0;i<size;i++)
     {
         al_draw_pixel(star_p3[i].x,star_p3[i].y,al_map_rgb(255,255,255));

     }

}
