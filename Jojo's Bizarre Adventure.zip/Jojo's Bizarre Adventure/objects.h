
//player

struct Player{
	int ID;
	int x;
	int y;  //acredito que Y teria que ser fixo
	int speed;
	int SBX1;
	int SBX2;
	int SBY;
	int vidas;
	int guard;
	int super;
	bool superstate;
	bool standby;
	bool walk;
	bool attack;
	bool dashstate;
	bool dmg;
	bool dir;

	int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;

};
struct Death{
    int maxFrame;
    int curFrame;
    int frameCount;
    int frameDelay;
    int frameWidth;
    int frameHeight;
};
struct Super{
    int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;
};

struct andar{
	int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;
};



struct def{
	int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;

};



struct atk{
	int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;
};

struct Dash{
	int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;
};

struct dmg {
	int maxFrame;
	int curFrame;
	int frameCount;
	int frameDelay;
	int frameWidth;
	int frameHeight;
};


