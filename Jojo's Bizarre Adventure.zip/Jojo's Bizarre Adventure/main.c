//JOGO : JOJO'S BIZARRE ADVENTURE por Pedro Pordeus e Jo�o Paulo Lamounier

#include <stdio.h>
#include <stdlib.h>
#include <allegro5\allegro.h>
#include <allegro5\allegro_primitives.h>
#include <allegro5\allegro_image.h>
#include "objects.h"
#define FPS 60
#define WIDTH 1413
#define HEIGHT 513
#define DASH 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3
#define UP 4
#define ATK 5
#define GUARD 6
#define UP2 7
#define DOWN2 8
#define LEFT2 9
#define RIGHT2 10
#define DASH2 11
#define ATK2 12
#define GUARD2 13
#define WIND_UP 3
#define ACTIVE 3
#define RECOVERY 6
#define WIND_UP_S 3
#define ACTIVE_S 5
#define RECOVERY_S 5


//Prototipos
void draw (struct Player *p);
void construct(struct Player *p, int player);

void moveUp (struct Player *p, struct Player *p2);
void moveDown (struct Player *p, struct Player *p2);
void moveLeft (struct Player *p, struct Player *p2);
void moveRight (struct Player *p, struct Player *p2);

void dash (struct Player *p);
void dashCoolDown (int dcount1, int dcount2);

int colisao (struct Player *p, struct Player *p2);
void ataque (struct Player *p, struct Player *p2, int fatk);
void especial (struct Player *p, struct Player *p2, int fspecial);
int defesa (struct Player *p);

void FramesDef (struct def *def, int player);
void FramesAndar (struct andar *walk, int player);
void FramesDash (struct Dash *d, int player);
void FramesDef (struct def *def, int player);
void FramesAtk1 (struct atk *atk, int player);
void FramesDmg (struct dmg *dmg, int player);
void FramesSuper(struct Super *sup, int player);
void FramesDeath (struct Death *d, int player);

void DrawLife (struct Player *p, struct Player *p2);

//Variaveis Globais
bool keys[14] = {false, false, false, false, false, false, false, false, false, false, false, false, false, false};


int main()
{
   	//Vari�veis primarias
   	bool done = false;
   	bool GameOver = false;


    //Vari�veis Allegro
    ALLEGRO_DISPLAY *display = NULL;
	ALLEGRO_EVENT_QUEUE  *event_queue = NULL;
	ALLEGRO_TIMER *timer = NULL;
	ALLEGRO_BITMAP *background = NULL;
	ALLEGRO_BITMAP *Menu = NULL;
    ALLEGRO_BITMAP *JotaroStanding = NULL;
    ALLEGRO_BITMAP *JotaroGuard = NULL;
    ALLEGRO_BITMAP *JotaroWalk = NULL;
    ALLEGRO_BITMAP *JotaroDash = NULL;
    ALLEGRO_BITMAP *JotaroAtk1 = NULL;
    ALLEGRO_BITMAP *JotaroSuper = NULL;
    ALLEGRO_BITMAP *JotaroDmg = NULL;
    ALLEGRO_BITMAP *JotaroDeath = NULL;
    ALLEGRO_BITMAP *JotaroWin = NULL;

    ALLEGRO_BITMAP *DioStanding = NULL;
    ALLEGRO_BITMAP *DioWalk = NULL;
    ALLEGRO_BITMAP *DioGuard = NULL;
    ALLEGRO_BITMAP *DioDash = NULL;
    ALLEGRO_BITMAP *DioAtk1 = NULL;
    ALLEGRO_BITMAP *DioSuper = NULL;
    ALLEGRO_BITMAP *DioDmg = NULL;
    ALLEGRO_BITMAP *DioDeath = NULL;
    ALLEGRO_BITMAP *DioWin = NULL;

   	//Fun��es de Inicializa��o
    al_init();
    display = al_create_display(WIDTH, HEIGHT);
    event_queue = al_create_event_queue();
    al_install_keyboard();
    timer = al_create_timer(1.0 / FPS);

    //Addons
    al_init_primitives_addon();
    al_init_image_addon();

    //Declara�ao dos BitMaps
    background = al_load_bitmap("background.png");
    Menu = al_load_bitmap("JojoMenu.png");
    JotaroStanding = al_load_bitmap("JotaroStanding.png");
    al_convert_mask_to_alpha(JotaroStanding, al_map_rgb(128, 128, 255));
    JotaroGuard = al_load_bitmap("JotaroGuard.png");
    al_convert_mask_to_alpha(JotaroGuard, al_map_rgb(128,128,255));
    JotaroWalk = al_load_bitmap("JotaroWalk.png");
    al_convert_mask_to_alpha(JotaroWalk, al_map_rgb(128,128,255));
    JotaroDash = al_load_bitmap("JotaroDash.png");
    al_convert_mask_to_alpha(JotaroDash, al_map_rgb(128,128,255));
    JotaroAtk1 = al_load_bitmap("JotaroAtk1.png");
    al_convert_mask_to_alpha(JotaroAtk1, al_map_rgb(128,128,255));
    JotaroSuper = al_load_bitmap("JotaroSuper.png");
    al_convert_mask_to_alpha(JotaroSuper, al_map_rgb(128,128,255));
    JotaroDmg = al_load_bitmap("JotaroDmg.png");
    al_convert_mask_to_alpha(JotaroDmg, al_map_rgb(128,128,255));
    JotaroDeath = al_load_bitmap("JotaroDeath.png");
    al_convert_mask_to_alpha(JotaroDeath, al_map_rgb(128,128,255));
    JotaroWin = al_load_bitmap("JotaroWin.png");


    DioStanding = al_load_bitmap("DioStanding.png");
    al_convert_mask_to_alpha(DioStanding, al_map_rgb(128, 128, 255));
    DioWalk = al_load_bitmap("DioWalk.png");
    al_convert_mask_to_alpha(DioWalk, al_map_rgb(128, 128, 255));
    DioGuard = al_load_bitmap("DioGuard.png");
    al_convert_mask_to_alpha(DioGuard, al_map_rgb(128, 128, 255));
    DioDash = al_load_bitmap("DioDash.png");
    al_convert_mask_to_alpha(DioDash, al_map_rgb(128, 128, 255));
    DioAtk1 = al_load_bitmap("DioAtk1.png");
    al_convert_mask_to_alpha(DioAtk1, al_map_rgb(128, 128, 255));
    DioSuper = al_load_bitmap("DioSuper.png");
    al_convert_mask_to_alpha(DioSuper, al_map_rgb(128,128,255));
    DioDmg = al_load_bitmap("DioDmg.png");
    al_convert_mask_to_alpha(DioDmg, al_map_rgb(128,128,255));
    DioDeath = al_load_bitmap("DioDeath.png");
    al_convert_mask_to_alpha(DioDeath, al_map_rgb(128,128,255));
    DioWin = al_load_bitmap("DioWin.png");


    //Eventos
    al_register_event_source(event_queue, al_get_keyboard_event_source());
    al_register_event_source(event_queue, al_get_timer_event_source(timer));


    //Variaveis da Main

    struct Player p1, *pp1;
    struct Player p2, *pp2;
    struct def def1, *pdef1, def2, *pdef2;
    struct atk atk1, atk2, *patk1, *patk2;
    struct andar andar1, andar2, *pandar1, *pandar2;
    struct Dash Dash1,*pDash1, Dash2, *pDash2;
    struct dmg dmg1, *pdmg1, dmg2, *pdmg2;
    struct Super super1, *psuper1, super2, *psuper2;
    struct Death death1, *pdeath1, death2, *pdeath2;
    int c, k=0;
   	int w, l;
    int animation, animation2;
    int frameCount;
    int frameCount2;
    int frameWidth;
    int frameWidth2;
    int frameHeight;
    int frameHeight2;
    int frameDelay = 6;
    int maxFrame = 0;
    int maxFrame2 = 0;
    int curFrame = 0;
    int curFrame2 = 0;
    int fdash1 = 7;
    int fdash2 = 5;
    int dcount1 = FPS;
    int dcount2 = FPS;
    int atkCDR1 = FPS;
    int atkCDR2 = FPS;
    bool acerto1 = true;
    bool acerto2 = true;
    bool dashEnd1 = false, dashEnd2 = false;
    bool start = false;

    //Ponteiros para passagem por referencia nas fun�oes
    pp1 = &p1;
    pp2 = &p2;
    pdef1 = &def1;
    pdef2 = &def2;
    pDash1 = &Dash1;
    pDash2 = &Dash2;
    pandar1 = &andar1;
    pandar2 = &andar2;
    patk1 = &atk1;
    patk2 = &atk2;
    pdmg1 = &dmg1;
    pdmg2 = &dmg2;
    psuper1 = &super1;
    psuper2 = &super2;
    pdeath1 = &death1;
    pdeath2 = &death2;

    //Fun�oes de inicializa�ao dos player e anima�oes, entrega parametros iniciais de caracteristicas de frames e status dos jogadores
    construct(pp1, 1);
    FramesDef(pdef1, 1);
    FramesAndar(pandar1, 1);
    FramesDash(pDash1, 1);
    FramesAtk1(patk1, 1);
    FramesDmg(pdmg1, 1);
    FramesSuper(psuper1, 1);
    FramesDeath(pdeath1, 1);

    construct(pp2, 2);
    FramesDef(pdef2, 2);
    FramesAndar(pandar2, 2);
    FramesDash(pDash2, 2);
    FramesAtk1(patk2, 2);
    FramesDmg(pdmg2, 2);
    FramesSuper(psuper2, 2);
    FramesDeath(pdeath2, 2);

    //Desenha O Menu
    al_draw_bitmap(Menu, 0, 0, 0);
    al_flip_display();

    al_start_timer(timer);

    //GameLoop
    while (!done){
    ALLEGRO_EVENT ev;
    //Espera uma tecla ser pressionada para come�ar o jogo
    if(start == false){
    al_wait_for_event(event_queue, &ev);
    if(ev.type == ALLEGRO_EVENT_KEY_DOWN) start = true;
    }
    else {
    if (GameOver){ //Checa se o jogo acabou para que as telas de vitoria sejam inicializadas baseadas em qual jogador ficou vivo no final
        if(p1.vidas > p2.vidas){
        al_draw_bitmap(JotaroWin, 0, 0, 0);
        al_flip_display();
        al_wait_for_event(event_queue, &ev);
        if(ev.type == ALLEGRO_EVENT_KEY_DOWN) done = true;
        }
        else {
        al_draw_bitmap(DioWin, 0, 0, 0);
        al_flip_display();
        al_wait_for_event(event_queue, &ev);
        if(ev.type == ALLEGRO_EVENT_KEY_DOWN) done = true;
        }
    }
    else{
    al_wait_for_event(event_queue, &ev);
    if(ev.type == ALLEGRO_EVENT_KEY_DOWN){
            //Switch para detec�ao dos comandos por teclado
			switch(ev.keyboard.keycode)
			{
			case ALLEGRO_KEY_ESCAPE:
				done = true;
				break;
			case ALLEGRO_KEY_W:
				keys[UP] = true;
				break;
			case ALLEGRO_KEY_S:
                keys[DOWN] = true;
				break;
			case ALLEGRO_KEY_A:
			     keys[LEFT] = true;
				break;
			case ALLEGRO_KEY_D:
                keys[RIGHT] = true;
				break;
            case ALLEGRO_KEY_H:
                keys[DASH] = true;
                break;
            case ALLEGRO_KEY_U:
                keys[ATK] = true;
                break;
            case ALLEGRO_KEY_I:
                keys[GUARD] = true;
                break;
            case ALLEGRO_KEY_UP:
                keys[UP2] = true;
                break;
            case ALLEGRO_KEY_DOWN:
                keys[DOWN2] = true;
                break;
            case ALLEGRO_KEY_LEFT:
                keys[LEFT2] = true;
                break;
            case ALLEGRO_KEY_RIGHT:
                keys[RIGHT2] = true;
                break;
            case ALLEGRO_KEY_PAD_0:
                keys[DASH2] = true;
                break;
            case ALLEGRO_KEY_PAD_2:
                keys[ATK2] = true;
                break;
            case ALLEGRO_KEY_PAD_3:
                keys[GUARD2]= true;
                break;
			}
    }
    if(ev.type == ALLEGRO_EVENT_KEY_UP){

			switch(ev.keyboard.keycode)
			{
			case ALLEGRO_KEY_ESCAPE:
				done = true;
				break;
			case ALLEGRO_KEY_W:
				keys[UP] = false;
				break;
			case ALLEGRO_KEY_S:
				keys[DOWN] = false;
				break;
			case ALLEGRO_KEY_A:
				keys[LEFT] = false;
				break;
			case ALLEGRO_KEY_D:
				keys[RIGHT] = false;
				break;
            case ALLEGRO_KEY_H:
                keys[DASH] = false;
                break;
            case ALLEGRO_KEY_I:
                keys[GUARD] = false;
                break;
            case ALLEGRO_KEY_U:
                keys[ATK] = false;
                break;
            case ALLEGRO_KEY_UP:
                keys[UP2] = false;
                break;
            case ALLEGRO_KEY_DOWN:
                keys[DOWN2] = false;
                break;
            case ALLEGRO_KEY_LEFT:
                keys[LEFT2] = false;
                break;
            case ALLEGRO_KEY_RIGHT:
                keys[RIGHT2] = false;
                break;
            case ALLEGRO_KEY_PAD_0:
                keys[DASH2] = false;
                break;
            case ALLEGRO_KEY_PAD_2:
                keys[ATK2] = false;
                break;
            case ALLEGRO_KEY_PAD_3:
                keys[GUARD2] = false;
                break;
    }
}
    if(ev.type == ALLEGRO_EVENT_TIMER){
        //Calculos Player 1
        //Checa se o estado de dano esta ativo
        if (p1.dmg == true){ //Caso seja verdadeiro o jogador nao podera realizar nenhuma a�ao, e seu ataque, caso estivesse ocorrendo, e cancelado
            if(p1.attack == true){
                atk1.curFrame = 0;
                atkCDR1 = 0;
            }
            p1.attack = false;
            p1.superstate = false;
            super1.curFrame = 0;
            p1.dashstate = false;
            p1.guard = false;
            p1.walk = false;
            p1.standby = false;
        }
        else{
    //Defesa
        if (keys[GUARD] && atkCDR1 > (FPS/2)){ //Necess�rio ser antes da movimenta��o para impedir o movimento caso ativo, mas deixar a dire�ao se alternar
            p1.guard = defesa(pp1);
            p1.speed = 0;
        }
        else {
            p1.guard = 0;
            def1.curFrame = 0;
            p1.speed = 6;
        }
    //Investida
        if (dcount1 == FPS && keys[DASH]){
            p1.dashstate = true;
        }
    //Movimenta�ao
        if(keys[UP] && !p1.dashstate && !p1.attack && !p1.superstate) moveUp(pp1, pp2);
        if(keys[DOWN] && !p1.dashstate && !p1.attack && !p1.superstate) moveDown(pp1, pp2);
        if(keys[LEFT] && !p1.dashstate && !p1.attack && !p1.superstate) moveLeft(pp1, pp2);
        if(keys[RIGHT] && !p1.dashstate && !p1.attack && !p1.superstate) moveRight(pp1, pp2);
    //Ataque
        if (((atkCDR1 == FPS) && keys[ATK] && !keys[GUARD] && p1.super < 2) || (atk1.curFrame > 0)){
            if (keys[ATK]  == true){
                keys[ATK] = false;
            }

            p1.attack = true;
            atkCDR1 = 0;
            ataque(pp1, pp2, atk1.curFrame);
            if(checaAcerto (pp1, pp2, atk1.curFrame) == 1 && acerto1 == true){
                p2.vidas --;
                p1.super ++;
                acerto1 = false;
                p2.dmg = true;
        }
        }

        else if (((atkCDR1 == FPS) && keys[ATK] && !keys[GUARD] && p1.super == 2) || (super1.curFrame > 0)){
            if (keys[ATK]  == true){
                keys[ATK] = false;
            }
            p1.superstate = true;
            atkCDR1 = 0;
            especial(pp1, pp2, super1.curFrame);
            if(checaAcerto (pp1, pp2, super1.curFrame) == 1 && acerto1 == true){
                p2.vidas -= 3;
                acerto1 = false;
                p2.dmg = true;
        }
        }
        }

    //Calculos Player 2
    //Mesmos calculos de player 1, porem com variaveis e structs proprias
        if (p2.dmg == true){
            if(p2.attack == true){
                atkCDR2 = 0;
                atk2.curFrame = 0;
            }
            p2.attack = false;
            p2.superstate = false;
            super2.curFrame = 0;
            p2.dashstate = false;
            p2.guard = false;
            p2.walk = false;
            p2.standby = false;
        }
    else  {
        //DEFESA
        if (keys[GUARD2] && atkCDR2 > (FPS/2)){
            p2.guard = defesa (pp2);
            p2.speed = 0;
        }
        else {
            p2.speed = 6;
            p2.guard = 0;
            def2.curFrame = 0;
        }
        //DASH ou Investida
        if (dcount2 == FPS && keys[DASH2]){
            p2.dashstate = true;
        }
        //MOVIMENTA��O
        if(keys[UP2] && !p2.dashstate && !p2.attack && !p2.superstate) moveUp(pp2, pp1);
        if(keys[DOWN2] && !p2.dashstate && !p2.attack && !p2.superstate) moveDown(pp2, pp1);
        if(keys[LEFT2] && !p2.dashstate && !p2.attack && !p2.superstate) moveLeft(pp2, pp1);
        if(keys[RIGHT2] && !p2.dashstate && !p2.attack && !p2.superstate) moveRight(pp2, pp1);

        //ATAQUE
        if (((atkCDR2 == FPS) && keys[ATK2] && !keys[GUARD2] && p2.super < 2) || (atk2.curFrame > 0)){
            if (keys[ATK2]  == true){
                keys[ATK2] = false;
            }

            p2.attack = true;
            atkCDR2 = 0;
            ataque(pp2, pp1, atk2.curFrame);
            if(checaAcerto(pp2, pp1, atk2.curFrame) == 1 && acerto2 == true){
                p1.vidas --;
                p2.super ++;
                acerto2 = false;
                p1.dmg = true;

        }
        }
        else if (((atkCDR2 == FPS) && keys[ATK2] && !keys[GUARD2] && p2.super == 2) || (super2.curFrame > 0)){
            if (keys[ATK2]  == true){
                keys[ATK2] = false;
            }
            p2.superstate = true;
            atkCDR2 = 0;
            especial(pp2, pp1, super2.curFrame);
            if(checaAcerto (pp2, pp1, super2.curFrame) == 1 && acerto2 == true){
                p1.vidas -= 3;
                acerto2 = false;
                p1.dmg = true;
        }
        }
        }


  //Anima�ao de Player 1
  //Primeiro checa se o player esta vivo para entao realizar as anima�oes
    if(p1.vidas <= 0){
            if(++death1.frameCount >= death1.frameDelay){
                    if(++death1.curFrame >= death1.maxFrame){
                             GameOver = true;
                        }
                death1.frameCount = 0;
            }
            frameCount = death1.frameCount;
            curFrame = death1.curFrame;
            maxFrame = death1.maxFrame;
            frameCount = death1.frameCount;
            frameWidth = death1.frameWidth;
            frameHeight = death1.frameHeight;
            animation = 7;
    }
    else {
        if(p1.dmg == true){
            if(++dmg1.frameCount >= dmg1.frameDelay){
                    if(++dmg1.curFrame >= dmg1.maxFrame){
                            dmg1.curFrame = 0;
                        }
                dmg1.frameCount = 0;
            }
            frameCount = dmg1.frameCount;
            curFrame = dmg1.curFrame;
            maxFrame = dmg1.maxFrame;
            frameCount = dmg1.frameCount;
            frameWidth = dmg1.frameWidth;
            frameHeight = dmg1.frameHeight;
            animation = 5;
        }
        else{


        //Checa se o player 1 est� em standby
       if (!p1.walk && !p1.attack && !p1.dashstate && !p1.guard && !p1.superstate){
            p1.standby = true;
        }
        else {
            p1.standby = false;
        }
        //Contador de Frames de Standby
        if (p1.standby == true) {
            if(++p1.frameCount >= frameDelay){
                    if(++p1.curFrame >= p1.maxFrame){
                            p1.curFrame = 0;
                        }
                p1.frameCount = 0;
            }
            p1.speed = 6;
            frameCount = p1.frameCount;
            curFrame = p1.curFrame;
            maxFrame = p1.maxFrame;
            frameCount = p1.frameCount;
            frameWidth = p1.frameWidth;
            frameHeight = p1.frameHeight;
            animation = 0;
        }

        //Anima�ao de defesa
        else if(p1.guard > 0){
            if(++def1.frameCount >= frameDelay){
                    if(++def1.curFrame >= def1.maxFrame){
                            def1.curFrame = 1;
                            def1.frameWidth = 277;
                        }
                    if(colisao(pp1, pp2) > 0 && !checaAcerto(pp2, pp1, atk2.curFrame) && acerto2 == true){
                            def1.curFrame = 2;
                            def1.frameWidth = 297;
                        }
                def1.frameCount = 0;

            }
            p1.dashstate = false;
            Dash1.curFrame = 0;
            frameCount = def1.frameCount;
            curFrame = def1.curFrame;
            maxFrame = def1.maxFrame;
            frameWidth = def1.frameWidth;
            frameHeight = def1.frameHeight;
            animation = 1;
        }

        //Animacao de Ataque
        if (p1.attack == true){
            if(++atk1.frameCount >= atk1.frameDelay){
                    if(++atk1.curFrame >= atk1.maxFrame){
                            acerto1 = true;
                            atk1.curFrame = 0;
                            p1.attack = false;
                        }
                atk1.frameCount = 0;
            }
            frameCount = atk1.frameCount;
            curFrame = atk1.curFrame;
            maxFrame = atk1.maxFrame;
            frameCount = atk1.frameCount;
            frameWidth = atk1.frameWidth;
            frameHeight = atk1.frameHeight;
            dcount1 = FPS - 2;
            animation = 4;
        }
        else if (p1.superstate == true){
            if(++super1.frameCount >= super1.frameDelay){
                    if(++super1.curFrame >= super1.maxFrame){
                            p1.super = 0;
                            acerto1 = true;
                            super1.curFrame = 0;
                            p1.superstate = false;
                        }
                super1.frameCount = 0;
            }
            frameCount = super1.frameCount;
            curFrame = super1.curFrame;
            maxFrame = super1.maxFrame;
            frameWidth = super1.frameWidth;
            frameHeight = super1.frameHeight;
            dcount1 = FPS - 2;
            animation = 6;
        }

        //Anima�ao de Dash
        if(p1.dashstate == true && p1.speed > 0){
            if(++Dash1.frameCount >= Dash1.frameDelay){
                    if(++Dash1.curFrame >= Dash1.maxFrame){
                            p1.dashstate = false;
                            Dash1.curFrame = 0;
                            dashEnd1 = true;

                    }
                dash(pp1);
                if(dashEnd1 == true){
                    if (colisao(pp1, pp2) > 0){
                        if (p1.dir) p1.x = p2.x + p2.frameWidth/2;
                        else p1.x = p2.x - p2.frameWidth/2;
                        dashEnd1 = false;
                        }
                }
                Dash1.frameCount = 0;

            }

            dcount1 = 0;
            frameCount = Dash1.frameCount;
            curFrame = Dash1.curFrame;
            maxFrame = Dash1.maxFrame;
            frameCount = Dash1.frameCount;
            frameWidth = Dash1.frameWidth;
            frameHeight = Dash1.frameHeight;
            animation = 2;
        }

        //Anima�ao de andar
        for(w=0; w<=4; w++){
             if (keys[w] == true && !p1.dmg) {
                  p1.walk = true;
                  l = 0;
             }
             else l++;

             if (l >= 4){
                p1.walk = false;
             }
        }
        if(p1.walk==true && !p1.attack && !p1.dashstate && !p1.guard && !p1.superstate) {
            if(++andar1.frameCount >= andar1.frameDelay){
                    if(++andar1.curFrame >= andar1.maxFrame){
                            andar1.curFrame = 0;
                        }
                andar1.frameCount = 0;
            }
            frameCount = andar1.frameCount;
            curFrame = andar1.curFrame;
            maxFrame = andar1.maxFrame;
            frameCount = andar1.frameCount;
            frameWidth = andar1.frameWidth;
            frameHeight = andar1.frameHeight;
            animation = 3;
        }
        }

    }

     //Anima�ao 2
    if(p2.vidas <= 0){
            if(++death2.frameCount >= death2.frameDelay){
                    if(++death2.curFrame >= death2.maxFrame){
                             GameOver = true;
                        }
                death2.frameCount = 0;
            }
            frameCount2 = death2.frameCount;
            curFrame2 = death2.curFrame;
            maxFrame2 = death2.maxFrame;
            frameCount2 = death2.frameCount;
            frameWidth2 = death2.frameWidth;
            frameHeight2 = death2.frameHeight;
            animation2 = 7;
    }
    else {
        if(p2.dmg == true){
            if(++dmg2.frameCount >= dmg2.frameDelay){
                    if(++dmg2.curFrame >= dmg2.maxFrame){
                            dmg2.curFrame = 0;
                        }
                dmg2.frameCount = 0;
            }
            frameCount2 = dmg2.frameCount;
            curFrame2 = dmg2.curFrame;
            maxFrame2 = dmg2.maxFrame;
            frameCount2 = dmg2.frameCount;
            frameWidth2 = dmg2.frameWidth;
            frameHeight2 = dmg2.frameHeight;
            animation2 = 5;
        }


        else {



        //Checa standby do player 2
        if (!p2.walk && !p2.attack && !p2.dashstate && !p2.guard && !p2.superstate){
            p2.standby = true;
        }
        else {
            p2.standby = false;
        }

        //Contador de Frames
       if (p2.standby == true) {
            if(++p2.frameCount >= frameDelay){
                    if(++p2.curFrame >= p2.maxFrame){
                            p2.curFrame = 0;
                        }
                p2.frameCount = 0;
            }
            frameCount2 = p2.frameCount;
            curFrame2 = p2.curFrame;
            maxFrame2 = p2.maxFrame;
            frameCount2 = p2.frameCount;
            frameWidth2 = p2.frameWidth;
            frameHeight2 = p2.frameHeight;
            animation2 = 0;
        }

         else if(p2.guard > 0){
            if(++def2.frameCount >= frameDelay){
                    if(++def2.curFrame >= def2.maxFrame){
                            def2.curFrame = 2;
                        }
                    if(colisao(pp2, pp1) > 0 && !checaAcerto(pp1, pp2, atk1.curFrame) && !p1.dashstate && acerto1 == true){
                            def2.curFrame = 3;
                        }
                def2.frameCount = 0;

            }
            p2.dashstate = false;
            Dash2.curFrame = 0;
            frameCount2 = def2.frameCount;
            curFrame2 = def2.curFrame;
            maxFrame2 = def2.maxFrame;
            frameCount2 = def2.frameCount;
            frameWidth2 = def2.frameWidth;
            frameHeight2 = def2.frameHeight;
            animation2 = 1;
        }

        //Animacao de ataque
          if (p2.attack == true){
            if(++atk2.frameCount >= atk2.frameDelay){
                    if(++atk2.curFrame >= atk2.maxFrame){
                            p2.speed = 6;
                            acerto2 = true;
                            atk2.curFrame = 0;
                            p2.attack = false;
                            p1.dmg = false;
                        }
                atk2.frameCount = 0;
            }

            frameCount2 = atk2.frameCount;
            curFrame2 = atk2.curFrame;
            maxFrame2 = atk2.maxFrame;
            frameCount2 = atk2.frameCount;
            frameWidth2 = atk2.frameWidth;
            frameHeight2 = atk2.frameHeight;
            dcount2 = FPS - 2;
            animation2 = 4;
        }
        else if (p2.superstate == true){
            if(++super2.frameCount >= super2.frameDelay){
                    if(++super2.curFrame >= super2.maxFrame){
                            p2.super = 0;
                            acerto2 = true;
                            super2.curFrame = 0;
                            p2.superstate = false;
                        }
                super2.frameCount = 0;
            }
            frameCount2 = super2.frameCount;
            curFrame2 = super2.curFrame;
            maxFrame2 = super2.maxFrame;
            frameWidth2 = super2.frameWidth;
            frameHeight2 = super2.frameHeight;
            dcount2 = FPS - 2;
            animation2 = 6;
        }
        //Anima�ao de Dash
        if(p2.dashstate == true && p2.speed > 0){
            if(++Dash2.frameCount >= Dash2.frameDelay){
                    if(++Dash2.curFrame >= Dash2.maxFrame){
                            p2.dashstate = false;
                            Dash2.curFrame = 0;
                            dashEnd2 = true;
                    }
                dash(pp2);
                 if(dashEnd2 == true){
                    if (colisao(pp2, pp1) > 0){
                        if (p2.dir) p2.x = p1.x + p1.frameWidth/2;
                        else p2.x = p1.x - p1.frameWidth/2;
                        dashEnd2 = false;
                        }
                }
                Dash2.frameCount = 0;

            }
            dcount2 = 0;
            frameCount2 = Dash2.frameCount;
            curFrame2 = Dash2.curFrame;
            maxFrame2 = Dash2.maxFrame;
            frameCount2 = Dash2.frameCount;
            frameWidth2 = Dash2.frameWidth;
            frameHeight2 = Dash2.frameHeight;
            animation2 = 2;
        }
        //Anima�ao de andar
           for(c=7; c<=10; c++){
             if (keys[c] == true && !p2.dmg) {
                  p2.walk = true;
                  k = 0;
            }
             else k++;
             if (k >= 4){
                p2.walk = false;
             }
        }

        if(p2.walk==true && !p2.attack && !p2.dashstate && !p2.guard && !p2.superstate) {
            if(++andar2.frameCount >= andar2.frameDelay){
                    if(++andar2.curFrame >= andar2.maxFrame){
                            andar2.curFrame = 0;
                        }
                andar2.frameCount = 0;
            }
            frameCount2 = andar2.frameCount;
            curFrame2 = andar2.curFrame;
            maxFrame2 = andar2.maxFrame;
            frameCount2 = andar2.frameCount;
            frameWidth2 = andar2.frameWidth;
            frameHeight2 = andar2.frameHeight;
            animation2 = 3;
        }
        }
    }









    //Desenha os BitMaps

    al_draw_bitmap(background, 0, 0, 0);

    if (p1.y <= p2.y){
            switch (animation){
            case 0:
            al_draw_bitmap_region(JotaroStanding, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 1:
            al_draw_bitmap_region(JotaroGuard, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 2:
            al_draw_bitmap_region(JotaroDash, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 3:
            al_draw_bitmap_region(JotaroWalk, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 4:
            al_draw_bitmap_region(JotaroAtk1, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 5:
            al_draw_bitmap_region(JotaroDmg, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 6:
            al_draw_bitmap_region(JotaroSuper, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 7:
            al_draw_bitmap_region(JotaroDeath, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            }

            switch (animation2){
            case 0:
            al_draw_bitmap_region(DioStanding, curFrame2 * frameWidth2,0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), (!p2.dir));
            break;
            case 1:
            al_draw_bitmap_region(DioGuard, curFrame2 * frameWidth2,0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), (!p2.dir));
            break;
            case 2:
            al_draw_bitmap_region(DioDash, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y - (frameHeight),(!p2.dir));
            break;
            case 3:
            al_draw_bitmap_region(DioWalk, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 4:
            al_draw_bitmap_region(DioAtk1, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 5:
            al_draw_bitmap_region(DioDmg, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 6:
            al_draw_bitmap_region(DioSuper, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 7:
            al_draw_bitmap_region(DioDeath, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            }
    }
    else {
            switch (animation2){
            case 0:
            al_draw_bitmap_region(DioStanding, curFrame2 * frameWidth2,0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), (!p2.dir));
            break;
            case 1:
            al_draw_bitmap_region(DioGuard, curFrame2 * frameWidth2,0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), (!p2.dir));
            break;
            case 2:
            al_draw_bitmap_region(DioDash, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y - (frameHeight),(!p2.dir));
            break;
            case 3:
            al_draw_bitmap_region(DioWalk, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 4:
            al_draw_bitmap_region(DioAtk1, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 5:
            al_draw_bitmap_region(DioDmg, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 6:
            al_draw_bitmap_region(DioSuper, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            case 7:
            al_draw_bitmap_region(DioDeath, curFrame2 * frameWidth2, 0, frameWidth2, frameHeight2, p2.x - (frameWidth2/2), p2.y-(frameHeight2), !p2.dir);
            break;
            }

         switch (animation){
            case 0:
            al_draw_bitmap_region(JotaroStanding, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 1:
            al_draw_bitmap_region(JotaroGuard, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 2:
            al_draw_bitmap_region(JotaroDash, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 3:
            al_draw_bitmap_region(JotaroWalk, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 4:
            al_draw_bitmap_region(JotaroAtk1, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 5:
            al_draw_bitmap_region(JotaroDmg, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 6:
            al_draw_bitmap_region(JotaroSuper, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            case 7:
            al_draw_bitmap_region(JotaroDeath, curFrame * frameWidth, 0, frameWidth, frameHeight, p1.x - (frameWidth/2), p1.y - (frameHeight),(!p1.dir));
            break;
            }
    }



    DrawLife(pp1, pp2);
    al_flip_display();



    //Contador do COOLDOWN de dash
    if(dcount1 < FPS){
        dcount1++;
    }
    if(dcount2 < FPS){
        dcount2++;
    }




    //Contador do COOLDOWN e Frames de ataque
    if (atkCDR1 < FPS){
        if (atkCDR1 == 1){
            p2.dmg = false;
        }
        atkCDR1 ++;
    }
    if (atkCDR2 < FPS){
        if(atkCDR2 == 1){
            p1.dmg = false;
        }
        atkCDR2 ++;
    }



    al_clear_to_color(al_map_rgb(0,0,0));
    }
    }
    }
}
al_destroy_bitmap(Menu);
al_destroy_bitmap(background);
al_destroy_bitmap(JotaroGuard);
al_destroy_bitmap(JotaroStanding);
al_destroy_bitmap(JotaroWalk);
al_destroy_bitmap(JotaroAtk1);
al_destroy_bitmap(JotaroDash);
al_destroy_bitmap(JotaroDmg);
al_destroy_bitmap(JotaroSuper);
al_destroy_bitmap(JotaroDeath);
al_destroy_bitmap(DioStanding);
al_destroy_bitmap(DioGuard);
al_destroy_bitmap(DioWalk);
al_destroy_bitmap(DioAtk1);
al_destroy_bitmap(DioDmg);
al_destroy_bitmap(DioDash);
al_destroy_bitmap(DioDeath);
al_destroy_display(display);

return 0;

}

FramesDeath (struct Death *d, int player){
    if(player == 1){
        d->frameHeight = 220;
        d->frameWidth = 400;
        d->frameCount = 0;
        d->curFrame = 0;
        d->maxFrame = 9;
        d->frameDelay = 8;
    }
    else {
        d->frameHeight = 244;
        d->frameWidth = 300;
        d->frameCount = 0;
        d->curFrame = 0;
        d->maxFrame = 12;
        d->frameDelay = 8;
    }
}

void FramesSuper (struct Super *sup, int player){
    if(player == 1){
        sup->frameHeight = 242;
        sup->frameWidth = 350;
        sup->frameCount = 0;
        sup->curFrame = 0;
        sup->maxFrame = 13;
        sup->frameDelay = 3;
    }
    else {
        sup->frameHeight = 280;
        sup->frameWidth = 350;
        sup->frameCount = 0;
        sup->curFrame = 0;
        sup->maxFrame = 13;
        sup->frameDelay = 3;
    }
}

void FramesDmg (struct dmg *dmg, int player){
    if(player == 1){
        dmg->frameHeight = 236;
        dmg->frameWidth = 280;
        dmg->frameCount = 0;
        dmg->curFrame = 0;
        dmg->maxFrame = 6;
        dmg->frameDelay = 4;
    }
    else {
        dmg->frameHeight = 239;
        dmg->frameWidth = 240;
        dmg->frameCount = 0;
        dmg->curFrame = 0;
        dmg->maxFrame = 7;
        dmg->frameDelay = 4;
    }
}

void FramesAtk1 (struct atk *atk, int player){

    if(player == 1){
        atk->frameHeight = 238;
        atk->frameWidth = 330;
        atk->frameCount = 0;
        atk->curFrame = 0;
        atk->maxFrame = 10;
        atk->frameDelay = 3;
    }
    else {
        atk->frameHeight = 241;
        atk->frameWidth = 300;
        atk->frameCount = 0;
        atk->curFrame = 0;
        atk->maxFrame = 12;
        atk->frameDelay = 3;
    }

}

void FramesDash (struct Dash *d, int player){
    if(player == 1){
        d->frameHeight = 236;
        d->frameWidth = 235;
        d->frameCount = 0;
        d->curFrame = 0;
        d->maxFrame = 7;
        d->frameDelay = 3;
    }
    else {
        d->frameHeight = 224;
        d->frameWidth = 240;
        d->frameCount = 0;
        d->curFrame = 0;
        d->maxFrame = 6;
        d->frameDelay = 3;
    }
}

void FramesAndar (struct andar *walk, int player){
    if(player == 1){
        walk->frameHeight = 229;
        walk->frameWidth = 200;
        walk->frameCount = 0;
        walk->curFrame = 0;
        walk->maxFrame = 16;
        walk->frameDelay = 4;
    }
    else {
        walk->frameHeight = 231;
        walk->frameWidth = 160;
        walk->frameCount = 0;
        walk->curFrame = 0;
        walk->maxFrame = 16;
        walk->frameDelay = 4;
    }
}

void FramesDef (struct def *def, int player){
    if(player == 1){
    def->frameHeight = 236;
    def->frameWidth = 277;
    def->frameCount = 0;
    def->curFrame = 0;
    def->maxFrame = 1;
    }
    else{
    def->frameHeight = 268;
    def->frameWidth = 200;
    def->frameCount = 0;
    def->curFrame = 0;
    def->maxFrame = 2;
    }
}

void construct(struct Player *p, int player){
if(player == 1){
p->ID = 1;
p->super = 0;
p->superstate = false;
p->dashstate = false;
p->walk = false;
p->attack = false;
p->vidas = 20;
p->speed = 6;
p->SBX1 = 20;
p->SBX2 = 20;
p->SBY = 30;
p->y = HEIGHT - 40;
p->x = 50;
p->frameHeight = 233;
p->frameWidth = 152;
p->frameCount = 0;
p->curFrame = 0;
p->maxFrame = 8;
p->dir = true;
p->dmg = false;
}
else {
p->ID = 2;
p->super = 0;
p->superstate = false;
p->dashstate = false;
p->walk = false;
p->attack = false;
p->vidas = 20;
p->speed = 6;
p->y = HEIGHT - 40;
p->x = WIDTH - 50;
p->SBX1 = 20;
p->SBX2 = 20;
p->SBY = 30;
p->frameHeight = 240;
p->frameWidth = 140;
p->frameCount = 0;
p->curFrame = 0;
p->maxFrame = 13;
p->dir = false;
p->dmg = false;
}
}

void moveUp (struct Player *p, struct Player *p2){

    p->y -= p->speed;
    if(p->y < (HEIGHT/2 + 25)){
        p->y = (HEIGHT/2 + 25);

    }
    else if(colisao(p, p2) > 0){
        p->y = p->y += p->speed;
    }
}

void moveDown (struct Player *p, struct Player *p2){

    p->y += p->speed;
    if(p->y > HEIGHT){
        p->y = HEIGHT;
    }
    else if(colisao(p, p2) > 0){
        p->y = p->y -= p->speed;
    }

}

void moveLeft (struct Player *p, struct Player *p2){

    p->x -= p->speed;
    if(p->x < 0){
        p->x = 0;
    }
    else if(colisao(p, p2) > 0){
        p->x = p->x += p->speed;
    }
    p->dir = false;
}

void moveRight (struct Player *p, struct Player *p2){

    p->x += p->speed;
    if(p->x >WIDTH){
        p->x = WIDTH;
    }
    else if(colisao(p, p2) > 0){
        p->x = p->x -= p->speed;
    }
    p->dir = true;

}

void dash (struct Player *p){
    if(p->dir){
    if (p->x >= WIDTH){
        p->x = WIDTH;
    }
    else p->x += p->speed * 8;

    }
    else if (!p->dir){
        if (p->x <= 0){
            p->x=0;
        }
        else p->x -= p->speed * 8;

    }
}

int colisao (struct Player *p, struct Player *p2){

    if (p->x - p2->x <= 0){
    if ((abs(p->x - p2->x) < (p2->SBX2 + p->SBX1)) && (abs(p->y - p2->y) < ((p2->SBY + p->SBY)-20))){
            return 1;
    }
    else return 0;
    }
    else if ((abs(p->x - p2->x) < (p2->SBX1 + p->SBX2)) && (abs(p->y - p2->y) < (p2->SBY + p->SBY)-20)){
    return 2;

    }
    else {
        return 0;
    }
}

void ataque (struct Player *p, struct Player *p2, int fatk){
    int c;
    if (p->dir){
        if(fatk < WIND_UP){
          moveRight(p, p2);
        }
        else if (fatk < WIND_UP + ACTIVE){
            p->SBX1 += 10;
            for (c=0; c<2; c++)
            moveRight(p, p2);
        }
        else if (fatk <= WIND_UP + ACTIVE + RECOVERY){
            p->SBX1 -= 10;
            if(p->SBX1 <= 20){
                p->SBX1 = 20;
            }
        }
    }
    else {
        if(fatk < WIND_UP){
          moveLeft(p, p2);
        }
        else if (fatk < WIND_UP + ACTIVE){
            p->SBX2 += 10;
            for (c=0; c<2; c++)
            moveLeft(p, p2);
        }
        else if (fatk <= WIND_UP + ACTIVE + RECOVERY){
            p->SBX2 -= 10;
            if(p->SBX2 <= 20){
                p->SBX2 = 20;
            }
        }
    }
    }


int checaAcerto (struct Player *p, struct Player *p2, int fatk){
    if (fatk > WIND_UP && fatk <= (WIND_UP + ACTIVE)){
        if (colisao(p, p2) == 1){
                if (p2->guard == 2){
                    return 0;
                }
                else if(p->SBX1 >= p2->SBX2){
                    return 1;
                }
                else return 0;
        }
        else if(colisao(p, p2) == 2){
                if (p2->guard == 1){
                    return 0;
                }
                else if(p->SBX2 >= p2->SBX1){
                    return 1;
                }
                else return 0;
        }
    else return 0;
    }
    else return 0;
}


int defesa (struct Player *p){
    if (p->dir){
        return 1;
    }
    else {
        return 2;
    }
}

void especial (struct Player *p, struct Player *p2, int fspecial){
    int c;
    if (p->dir){
        if(fspecial < WIND_UP_S){
          moveRight(p, p2);
        }
        else if (fspecial < WIND_UP_S + ACTIVE_S){
            p->SBX1 += 10;
            for (c=0; c<2; c++)
            moveRight(p, p2);
        }
        else if (fspecial <= WIND_UP_S + ACTIVE_S + RECOVERY_S){
            p->SBX1 = 20;
        }
    }
    else {
        if(fspecial < WIND_UP_S){
          moveLeft(p, p2);
        }
        else if (fspecial < WIND_UP_S + ACTIVE_S){
            p->SBX2 += 10;
            for (c=0; c<2; c++)
            moveLeft(p, p2);
        }
        else if (fspecial <= WIND_UP_S + ACTIVE_S + RECOVERY_S){
            p->SBX2 = 20;
        }
    }
}

void DrawLife (struct Player *p, struct Player *p2){
if(p2->vidas < 0) p2->vidas = 0;
if(p->vidas < 0) p->vidas = 0;
al_draw_filled_rectangle(13, 470, 413, 503, al_map_rgb(0,0,0));
al_draw_filled_rectangle(13, 470, p->vidas*20 + 13, 503, al_map_rgb (77, 77, 255));
al_draw_filled_rectangle(1000, 470, 1400, 503, al_map_rgb(0,0,0));
al_draw_filled_rectangle(1000+(20-p2->vidas)*20, 470, 1400, 503, al_map_rgb(217,217,25));
}
